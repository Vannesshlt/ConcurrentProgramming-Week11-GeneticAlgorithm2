/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


/**
 *
 * @author Chin Yi Jia/14057061
 * 		   Tan Hoi Leong/
 */
public class GeneticAlgorithm {
	/**
	 * @param args
	 *            the command line arguments
	 */
	public static String[] funcName = { "Schwefel", "Rosenbrock", "Rastrigin" }; // function name
	public static final int popSize = 300, indSize = 100, id = 0,
			threadSize = 5; // population and individual size, function id and thread pool size
	public static int generation = 0, endGeneration = 1000, startGraph, endGraph;
	public static double globalBestFit = Double.MAX_VALUE, mutateValue = 1;
	public static ArrayList<Double> minimumofgeneration = new ArrayList<Double>();

	public static EvaluateFitnessTask[] evaluateFitnessTask; // task to evaluate function based on function id
	public static FindFitnessTask findFitnessTask;           // task to find average, best and worst fitness
	public static CrossPopulateTask[] crossPopulateTask;     // task to cross populate between parents to produce offspring
	public static Mutate_ChangePopulationTask[] mutate_ChangePopulationTask; //task to mutate each individuals value
	public static Individual[] populations, newPopulations;  // arrays of population and the new offspring population

	public static ExecutorService exec1 = Executors.newFixedThreadPool(threadSize);
	public static ArrayList<Future<Double>> future = new ArrayList<Future<Double>>();
	
	public static void main(String[] args) {
		int interval = 0, startingInterval = 0;
		startGraph = generation;

		double[][] initArray = new double[popSize][indSize]; // initialize 2D array
		double[] fitness = new double[initArray.length];     // array of fitness for population size
		double[] range = { 510, 2.048, 5.12 };			     // function range values uniquely for different id
		populations = new Individual[initArray.length];      // create arrays of size of population
		newPopulations = new Individual[initArray.length];

		evaluateFitnessTask = new EvaluateFitnessTask[initArray.length]; 
		findFitnessTask = new FindFitnessTask(generation, fitness);
		crossPopulateTask = new CrossPopulateTask[threadSize];
		mutate_ChangePopulationTask = new Mutate_ChangePopulationTask[initArray.length];
		
		interval = popSize / crossPopulateTask.length; // this is to provide the
													   // crossPopulateTask to
													   // be split evenly into
													   // 5 tasks equally for different population's range cross over
		
		for(int count=0;count<crossPopulateTask.length;count++)
		{
			crossPopulateTask[count] = new CrossPopulateTask(startingInterval, startingInterval + interval,
					populations, newPopulations,fitness);
			startingInterval += interval;
		}
		
		generatePopulation(initArray, range[id]);    // random assign values method based on the range id function
		Long starting = System.currentTimeMillis();
		doFunction(fitness);						 // starts the function
		exec1.shutdown();							 // wait executors to be shut down peacefully
		Long total = System.currentTimeMillis() - starting;
		System.out.println("Total time in ms is: " + total + " milisecond");
		endGraph = generation-1;

		LineChart_AWT chart = new LineChart_AWT(
				"Minimum value for each generations",
				"Minimum value for each generations");

		chart.pack();
		RefineryUtilities.centerFrameOnScreen(chart);
		chart.setVisible(true);
	}
    
	public static void generatePopulation(double[][] initArray, double range) {
		for (int row = 0; row < initArray.length; row++) {
			for (int column = 0; column < indSize; column++) {
				initArray[row][column] = ThreadLocalRandom.current()
						.nextDouble(-range, range);
			}
			populations[row] = new Individual(initArray, row, indSize); // convert each population into 1D array
			newPopulations[row] = new Individual(initArray, row, indSize);
			evaluateFitnessTask[row] = new EvaluateFitnessTask(
					populations[row], id); // binds the task specifically to
										   // each unique population
			mutate_ChangePopulationTask[row] = new Mutate_ChangePopulationTask(populations[row],
					newPopulations[row], range);
		}
	}
    
	// start doing function until it reaches end generation
	// all the task is run in this method
	// in findFitnessTask, crossPopulateTask, mutate_ChangePopulationTask,
	// future.get() is used instead executor shutdown as shutdown will need to
	// recreate new executor to prevent the code for further executing without waiting the tasks to be completed
	// in findFitnessTask, crossPopulateTask, mutate_ChangePopulationTask, future.get() will return 0.0
	public static void doFunction(double[] fitness) {
		do {
			future.clear();
			for (int row = 0; row < popSize; row++) {
				future.add(exec1.submit(evaluateFitnessTask[row]));
			}
			for (int row = 0; row < popSize; row++) {
				try {fitness[row] = future.get(row).get();} // returns the fitness value
				catch (ExecutionException e) {} catch (InterruptedException e) {}
			}

			future.clear();
			future.add(exec1.submit(findFitnessTask));
			try {future.get(0).get();} 
			catch (ExecutionException e) {} catch (InterruptedException e) {}

			future.clear();
			for (int x = 0; x < crossPopulateTask.length; x++) {
				future.add(exec1.submit(crossPopulateTask[x]));
			}
			for (int x = 0; x < crossPopulateTask.length; x++) {
				try {future.get(x).get();}
				catch (ExecutionException e) {} catch (InterruptedException e) {}
			}

			future.clear();
			for (int row = 0; row < popSize; row++) {
				future.add(exec1.submit(mutate_ChangePopulationTask[row]));
			}
			for (int row = 0; row < popSize; row++) {
				try {future.get(row).get();} 
				catch (ExecutionException e) {} catch (InterruptedException e) {}
			}

			changeMutateValue();
		} while (generation++ < endGeneration);
		System.out.printf("%s function minimum: %f\n", funcName[id],
				globalBestFit);
	}

	// as generation increases, mutateValue become smaller
	public static void changeMutateValue() {
		if (generation % 50 == 0) {
			if (mutateValue >= 0.2) {
				mutateValue -= 0.1;
			} else if (mutateValue >= 0.02) {
				mutateValue -= 0.03;
			} else if (mutateValue >= 0.002) {
				mutateValue -= 0.003;
			}

		}
		if(globalBestFit<0)
		{
			mutateValue+=0.1;
		}
	}
}

// drawing graph class
class LineChart_AWT extends ApplicationFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LineChart_AWT(String applicationTitle, String chartTitle) {
		super(applicationTitle);
		JFreeChart lineChart = ChartFactory.createLineChart(chartTitle,
				"Number of Generations", "Minimum Value", createDataset(),
				PlotOrientation.VERTICAL, true, true, false);

		ChartPanel chartPanel = new ChartPanel(lineChart);
		chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
		setContentPane(chartPanel);
	}

	// adding each generation minimum value to the graph
	private DefaultCategoryDataset createDataset() {

		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		for (int row = GeneticAlgorithm.startGraph; row < GeneticAlgorithm.endGraph; row++) {
			dataset.addValue(GeneticAlgorithm.minimumofgeneration.get(row),
					GeneticAlgorithm.funcName[GeneticAlgorithm.id], String.valueOf(row + 1));
		}
		return dataset;
	}
}


