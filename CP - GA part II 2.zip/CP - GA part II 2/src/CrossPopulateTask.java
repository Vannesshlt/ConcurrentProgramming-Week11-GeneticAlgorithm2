import java.util.Random;
import java.util.concurrent.Callable;

// task to cross populate between two parents to generate offsprings
public class CrossPopulateTask implements Callable<Double> {

	private Individual[] populations, newPopulations;            // arrays of population and new population
	private double[] fitness;								    // fitness for each population	
	
	public int start, end, tourSize = 3, firstChildSecondPart,  // start and end indicates the task cross populate for 
																// certain population range
			secondChildFirstPart, reverseCutLine;

	public CrossPopulateTask(int start, int end, Individual[] population,
			Individual[] newPopulations, double[] fitness) {
		this.start = start;
		this.end = end;
		this.populations = population;
		this.newPopulations = newPopulations;
		this.fitness = fitness;
	}

	@Override
	public Double call() {
		crossPopulate();
		return 0.0;
	}
	
	// two parents cross over to generate offspring
	// 70% of cross over
	// 30% of keeping same parents
	// cutLine indicates the intersection point to be crossed over for two parents
	// reverseCutLine is to make sure second child will have first second part
	// of first parent in the second child first part to prevent two new child same
	public void crossPopulate() {
		Random rand = new Random();
		int cutLine = 0, newPopSize = start, indSize = GeneticAlgorithm.indSize;
		double[] tempArrOne = new double[indSize];
		double[] tempArrTwo = new double[indSize];
		double[] newChildOne = new double[indSize];
		double[] newChildTwo = new double[indSize];
		while (newPopSize < end) {
			tournamentFight(tempArrOne, tempArrTwo, indSize);

			if (rand.nextDouble() < 0.7) {
				cutLine = rand.nextInt(indSize);
				firstChildSecondPart = cutLine;
				secondChildFirstPart = 0;
				reverseCutLine = indSize - cutLine;

				for (int column = 0; column < cutLine; column++) {
					newChildOne[column] = tempArrOne[column];
				}
				for (int column = cutLine; column < indSize; column++) {
					newChildOne[column] = tempArrTwo[column];
				}
				for (int column = 0; column < reverseCutLine; column++) {
					newChildTwo[column] = tempArrOne[firstChildSecondPart++];
				}
				for (int column = reverseCutLine; column < indSize; column++) {
					newChildTwo[column] = tempArrTwo[secondChildFirstPart++];
				}

				for (int column = 0; column < indSize; column++) {
					newPopulations[newPopSize].getIndividuals()[column] = newChildOne[column];
				}
				newPopSize++;
				for (int column = 0; column < indSize; column++) {
					newPopulations[newPopSize].getIndividuals()[column] = newChildTwo[column];
				}
				newPopSize++;
			} else {
				for (int column = 0; column < indSize; column++) {
					newPopulations[newPopSize].getIndividuals()[column] = tempArrOne[column];
				}
				newPopSize++;
				for (int column = 0; column < indSize; column++) {
					newPopulations[newPopSize].getIndividuals()[column] = tempArrTwo[column];
				}
				newPopSize++;
			}
		}
	}

	// choose two parents that wins the fight with least fitness value
	public void tournamentFight(double[] tempArrOne, double[] tempArrTwo, int sizes) {
		findChallenger(tempArrOne,sizes);
		findChallenger(tempArrTwo,sizes);
	}
	
	// tournament of size 3 to determine the winner parent to be chosen
	public void findChallenger(double[] tempArr, int sizes) {
		Random rand = new Random();
		double bestFitness = Double.MAX_VALUE;
		int indSize = sizes;
		int[] tournament = new int[tourSize];
		
		tournament[0] = rand.nextInt(populations.length);
		for (int count = 1; count < tournament.length; count++) {
			tournament[count] = rand.nextInt(populations.length);
			if (tournament[count] == tournament[count - 1]) {
				count--;
			}
		}

		for (int count = 0; count < tournament.length; count++) {
			if (bestFitness > fitness[tournament[count]]) {
				for (int x = 0; x < indSize; x++) {
					tempArr[x] = populations[tournament[count]].getIndividuals()[x];
				}
				bestFitness = fitness[tournament[count]];
			}
		}
	}
	
}
