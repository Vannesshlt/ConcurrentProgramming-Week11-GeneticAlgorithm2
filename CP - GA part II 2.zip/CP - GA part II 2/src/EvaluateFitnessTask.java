/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.concurrent.Callable;

/**
 *
 * @author 14057061
 */
// task to evaluate fitness based on the function
public class EvaluateFitnessTask implements Callable<Double> {

	private double[] individual;	    // each task own self evaluate each 1D population individuals	    
	private int id;					// id determines which function to be chosen
	private final double alpha = 418.982887;

	public EvaluateFitnessTask(Individual population, int id) {
		individual = population.getIndividuals();
		this.id = id;
	}

	@Override
	public Double call() {
		double fitness = 0;
		switch (id) {
		case 0:
			fitness = schwefel();
			break;
		case 1:
			fitness = rosenBrock();
			break;
		case 2:
			fitness = rastrigin();
			break;
		}
		return fitness;
	}

	public double schwefel() {
		double individualFitness = 0;
		for (int column = 0; column < individual.length; column++) {
			individualFitness += ((-individual[column] * Math.sin(Math
					.sqrt(Math.abs(individual[column])))));
		}
		return individualFitness + (alpha * individual.length);
	}

	public double rosenBrock() {
		double individualFitness = 0;
		for (int column = 0; column < individual.length - 1; column++) {
			individualFitness += (100 * (Math
					.pow(individual[column + 1]
							- Math.pow(individual[column], 2), 2)))
					+ (Math.pow((individual[column] - 1), 2));
		}
		return individualFitness;
	}

	public double rastrigin() {
		double individualFitness = 0;
		for (int column = 0; column < individual.length; column++) {
			individualFitness += (individual[column] * individual[column])
					- (10 * Math.cos(2 * Math.PI * individual[column]));
		}
		return individualFitness + (10 * individual.length);
	}

}
