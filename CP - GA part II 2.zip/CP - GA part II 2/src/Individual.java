
// Individual class to convert each array of individuals holds a population individuals
public class Individual {

	private double[] individuals;

	public Individual(double[][] population, int row, int indSize) {
		individuals = new double[indSize];
		for (int column = 0; column < indSize; column++) {
			individuals[column] = population[row][column];
		}
	}

	public double[] getIndividuals() {
		return individuals;
	}

}
