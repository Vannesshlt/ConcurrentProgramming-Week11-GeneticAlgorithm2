import java.util.concurrent.Callable;


// task to find the average, best and worst fitness for each generation
public class FindFitnessTask implements Callable<Double>{
	
	private int generation;
	private double[] fitness;

	public FindFitnessTask(int generation, double[] fitness) {
		this.generation = generation;
		this.fitness = fitness;
	}
	
	public Double call() {
		System.out.printf("Generation: %d, max: %f, min: %f, average: %f\n",
				generation, findWorstFitness(fitness),
				findBestFitness(fitness), findAvg(fitness));
		generation++;
		return 0.0;
	}

	public static double findWorstFitness(double[] fitness) {
		double worstFit = Double.MIN_VALUE;
		for (int row = 0; row < fitness.length; row++) {
			if (worstFit <= fitness[row]) {
				worstFit = fitness[row];
			}
		}
		return worstFit;
	}

	public static double findBestFitness(double[] fitness) {
		double bestFit = Double.MAX_VALUE;
		for (int row = 0; row < fitness.length; row++) {
			if (bestFit >= fitness[row]) {
				bestFit = fitness[row];
			}
		}
		if (GeneticAlgorithm.globalBestFit >= bestFit) {
			GeneticAlgorithm.globalBestFit = bestFit;
		}
		GeneticAlgorithm.minimumofgeneration.add(bestFit);

		return bestFit;
	}

	public static double findAvg(double[] fitness) {
		double avg = 0;
		for (int row = 0; row < fitness.length; row++) {
			avg += fitness[row];
		}
		return (avg / fitness.length);
	}
}
