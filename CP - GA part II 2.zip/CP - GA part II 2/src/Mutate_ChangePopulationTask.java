import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Random;

// task to mutate and change whole population into new population
public class Mutate_ChangePopulationTask implements Callable<Double> {
	private double range; 				// function range values
	private double[] parent, newParent;  // parent will be replaced with newParent values

	public Mutate_ChangePopulationTask(Individual population,
			Individual newPopulation, double range) {
		parent = population.getIndividuals();
		newParent = newPopulation.getIndividuals();
		this.range=range;
	}

	public Double call() {
		mutate();
		changePopulation();
		return 0.0;
	}

	// mutate method will random +- each newParents values with mutation rate of 1%
	public void mutate() {
		Random rand = new Random();
		double random = 0, temp = 0, mutateRate = 0.01;
		for (int column = 0; column < parent.length; column++) {
			if (rand.nextDouble() < mutateRate) {
				random = ThreadLocalRandom.current().nextDouble(
						-GeneticAlgorithm.mutateValue,
						GeneticAlgorithm.mutateValue);
				temp = newParent[column];
				newParent[column] = newParent[column] + random;
				if (newParent[column] < -this.range
						|| newParent[column] > this.range) {
					newParent[column] = temp;
					column--;
				}
			}
		}
	}

	// change all parent into newParent values
	public void changePopulation() {
		for (int column = 0; column < parent.length; column++) {
			parent[column] = newParent[column];
		}
	}
}